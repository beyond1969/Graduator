﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour {

    private GameObject obj;
    private bool visible;
    private float timer;
    private float waitingTime;

	// Use this for initialization
	void Start () {
        obj = GameObject.Find("Game_start");
        visible = true;
        timer = 0.0f;
        waitingTime = 0.8f;
	}
	
	// Update is called once per frame
	void Update () {
        timer += Time.deltaTime;
        if(timer > waitingTime)
        {
            obj.SetActive(!visible);
            timer = 0;
        }
	}
}
